package se.citerus.dddsample.domain.model.voyage;

import junit.framework.TestCase;

public class ScheduleTest extends TestCase {

    public void testCarrierMovements() throws Exception {
        //TODO: Test goes here...
    }

    public void testSameValueAs() throws Exception {
        //TODO: Test goes here...
    }

    public void testCopy() throws Exception {
        //TODO: Test goes here...
    }

    public void testEquals() throws Exception {
        //TODO: Test goes here...
    }

    public void testHashCode() throws Exception {
        //TODO: Test goes here...
    }


}
