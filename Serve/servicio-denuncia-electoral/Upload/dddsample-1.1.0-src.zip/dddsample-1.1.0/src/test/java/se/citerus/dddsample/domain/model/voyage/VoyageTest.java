package se.citerus.dddsample.domain.model.voyage;

import junit.framework.TestCase;

public class VoyageTest extends TestCase {

    public void testVoyageNumber() throws Exception {
        //TODO: Test goes here...
    }

    public void testSchedule() throws Exception {
        //TODO: Test goes here...
    }

    public void testHashCode() throws Exception {
        //TODO: Test goes here...
    }

    public void testEquals() throws Exception {
        //TODO: Test goes here...
    }

    public void testSameIdentityAs() throws Exception {
        //TODO: Test goes here...
    }

    public void testToString() throws Exception {
        //TODO: Test goes here...
    }

    public void testAddMovement() throws Exception {
        //TODO: Test goes here...
    }

    public void testBuild() throws Exception {
        //TODO: Test goes here...
    }


}
