package se.citerus.dddsample.domain.model.voyage;

import junit.framework.TestCase;

public class VoyageNumberTest extends TestCase {

    public void testEquals() throws Exception {
        //TODO: Test goes here...
    }

    public void testHashCode() throws Exception {
        //TODO: Test goes here...
    }

    public void testSameValueAs() throws Exception {
        //TODO: Test goes here...
    }

    public void testCopy() throws Exception {
        //TODO: Test goes here...
    }

    public void testToString() throws Exception {
        //TODO: Test goes here...
    }

    public void testIdString() throws Exception {
        //TODO: Test goes here...
    }


}
