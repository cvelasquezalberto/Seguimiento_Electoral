@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.handling.interfaces.dddsample.citerus.se/")
package com.aggregator;
